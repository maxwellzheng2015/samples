﻿namespace AwesomeService
{
    public interface IPersonRepository
    {
        string[] GetNames();
    }
}
﻿namespace AwesomeServer
{
    public class AwesomeServerOptions
    {
        public string FolderPath { get; set; }
    }

}

﻿namespace AwesomeApi
{
    public class EmotionResultDto
    {
        public EmotionScoresDto Scores { get; set; }
    }
}

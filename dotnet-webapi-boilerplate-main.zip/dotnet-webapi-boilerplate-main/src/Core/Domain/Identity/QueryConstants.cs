﻿namespace DN.WebApi.Domain.Constants;

public static class QueryConstants
{
    public const string Tenant = "tenant";
    public const string Code = "code";
    public const string UserId = "userId";
}
﻿namespace DN.WebApi.Domain.Constants;

public static class HeaderConstants
{
    public const string Tenant = "tenant";
}
using DN.WebApi.Domain.Common.Contracts;

namespace DN.WebApi.Domain.Dashboard;

public class StatsChangedEvent : DomainEvent
{
}
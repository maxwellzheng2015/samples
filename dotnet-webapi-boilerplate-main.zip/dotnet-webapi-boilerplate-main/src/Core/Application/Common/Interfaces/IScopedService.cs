namespace DN.WebApi.Application.Common.Interfaces;

public interface IScopedService
{
}
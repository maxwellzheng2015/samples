namespace DN.WebApi.Shared.DTOs.Identity;

public class UserRolesResponse
{
    public List<UserRoleDto> UserRoles { get; set; } = new();
}
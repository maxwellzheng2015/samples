namespace DN.WebApi.Shared.DTOs.Identity;

public class RoleDto
{
    public string? Id { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? Tenant { get; set; }
}
namespace DN.WebApi.Shared.DTOs.Identity;

public record TokenRequest(string Email, string Password);
namespace DN.WebApi.Shared.DTOs.Identity;

public class PermissionDto
{
    public string? Permission { get; set; }
    public string? Description { get; set; }
}
using DN.WebApi.Shared.DTOs.Filters;

namespace DN.WebApi.Shared.DTOs.Catalog;

public class BrandListFilter : PaginationFilter
{
}
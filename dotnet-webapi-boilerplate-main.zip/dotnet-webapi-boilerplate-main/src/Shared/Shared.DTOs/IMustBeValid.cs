namespace DN.WebApi.Shared.DTOs;

public interface IMustBeValid
{
}
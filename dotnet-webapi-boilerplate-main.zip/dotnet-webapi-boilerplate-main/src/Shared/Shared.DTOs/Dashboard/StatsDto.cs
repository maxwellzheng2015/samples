namespace DN.WebApi.Shared.DTOs.Dashboard;

public class StatsDto
{
    public int ProductCount { get; set; }
    public int BrandCount { get; set; }
    public int UserCount { get; set; }
    public int RoleCount { get; set; }
}
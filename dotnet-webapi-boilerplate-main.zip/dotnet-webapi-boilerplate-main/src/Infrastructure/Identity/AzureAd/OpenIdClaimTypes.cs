﻿namespace DN.WebApi.Infrastructure.Identity.AzureAd;

internal static class OpenIdConnectClaimTypes
{
    public const string Issuer = "iss";
}
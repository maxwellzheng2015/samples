﻿namespace DN.WebApi.Infrastructure.Identity.AzureAd;

internal static class AzureADClaimTypes
{
    public const string ObjectId = "http://schemas.microsoft.com/identity/claims/objectidentifier";
}
export interface City {
    id: number;
    name: string;
    lat: number;
    lon: number;
}
